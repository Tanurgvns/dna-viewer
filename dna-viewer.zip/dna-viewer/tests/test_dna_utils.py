import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest
import dna_utils as du


def test_parse_fasta_multiple_records():
    recs = du.parse_fasta(">a desc\nACGT\nacgt\n>b\nGGCC\n")
    assert [r.header for r in recs] == ["a desc", "b"]
    assert recs[0].sequence == "ACGTACGT"


def test_parse_plain_sequence_and_rna():
    recs = du.parse_fasta("acg u 12 ac")
    assert recs[0].sequence == "ACGTAC"


def test_invalid_chars_become_n():
    seq, bad = du.clean_sequence("ACGXZ")
    assert seq == "ACGNN" and bad == 2


def test_reverse_complement():
    assert du.reverse_complement("ATGCN") == "NGCAT"


def test_gc_content_ignores_n():
    assert du.gc_content("GGCCNNNN") == 100
    assert du.gc_content("ATGC") == 50


def test_translate():
    assert du.translate("ATGGCCTAA") == "MA*"
    assert du.translate("ATGGCCTAA", stop_at_stop=True) == "MA"


def test_find_orfs_forward_and_reverse():
    orf = "ATG" + "GCT" * 10 + "TAA"          # 11 aa
    seq = "CC" + orf + "GG"
    hits = du.find_orfs(seq, min_aa=5)
    assert any(o.strand == "+" and o.start == 3 and o.end == 2 + len(orf) for o in hits)

    rev = du.find_orfs(du.reverse_complement(seq), min_aa=5)
    o = next(o for o in rev if o.strand == "-")
    assert (o.start, o.end) == (3, 2 + len(orf))
    assert o.protein == "M" + "A" * 10


def test_find_motif_both_strands_and_iupac():
    seq = "AAGAATTCAA"   # EcoRI is palindromic, so hit on both strands
    hits = du.find_motif(seq, "GAATTC")
    assert {(h["strand"], h["start"]) for h in hits} == {("+", 3), ("-", 3)}
    assert len(du.find_motif("ACGTACG", "ACN", both_strands=False)) == 2


def test_bad_motif():
    with pytest.raises(ValueError):
        du.find_motif("ACGT", "AXG")
